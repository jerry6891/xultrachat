<?php
/*
Plugin Name: Sweipe Post Types
Plugin URI: http://mobius.studio/
Description: This plugin contains taxonomy and post types for testimonials and portfolio.
Author: Mobius Studio
Version: 1.0
Author URI: http://mobius.studio/
*/


if ( ! function_exists('mstudio_testimonials_taxonomy') ) {
	add_action( 'init', 'mstudio_testimonials_taxonomy', 0 );
	function mstudio_testimonials_taxonomy() {
		// Add new taxonomy, make it hierarchical (like categories)
		$labels = array(
			'name'              => _x( 'Testimonial Categories', 'taxonomy general name', 'mstudio' ),
			'singular_name'     => _x( 'Testimonial Category', 'taxonomy singular name', 'mstudio' ),
			'search_items'      => __( 'Search Testimonial Categories', 'mstudio' ),
			'all_items'         => __( 'All Testimonial Categories', 'mstudio' ),
			'parent_item'       => __( 'Parent Testimonial Category', 'mstudio' ),
			'parent_item_colon' => __( 'Parent Testimonial Category:', 'mstudio' ),
			'edit_item'         => __( 'Edit Testimonial Category', 'mstudio' ),
			'update_item'       => __( 'Update Testimonial Category', 'mstudio' ),
			'add_new_item'      => __( 'Add New Testimonial Category', 'mstudio' ),
			'new_item_name'     => __( 'New Testimonial Category Name', 'mstudio' ),
			'menu_name'         => __( 'Testimonial Category', 'mstudio' ),
		);

		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'testimonial_category' ),
		);

		register_taxonomy( 'testimonial_categories', array( 'testimonials' ), $args );
	}
}

if ( ! function_exists('mstudio_portfolio_taxonomy') ) {
	add_action( 'init', 'mstudio_portfolio_taxonomy', 0 );
	function mstudio_portfolio_taxonomy() {
		// Add new taxonomy, make it hierarchical (like categories)
		$labels = array(
			'name'              => _x( 'Portfolio Categories', 'taxonomy general name', 'mstudio' ),
			'singular_name'     => _x( 'Portfolio Category', 'taxonomy singular name', 'mstudio' ),
			'search_items'      => __( 'Search Portfolio Categories', 'mstudio' ),
			'all_items'         => __( 'All Portfolio Categories', 'mstudio' ),
			'parent_item'       => __( 'Parent Portfolio Category', 'mstudio' ),
			'parent_item_colon' => __( 'Parent Portfolio Category:', 'mstudio' ),
			'edit_item'         => __( 'Edit Portfolio Category', 'mstudio' ),
			'update_item'       => __( 'Update Portfolio Category', 'mstudio' ),
			'add_new_item'      => __( 'Add New Portfolio Category', 'mstudio' ),
			'new_item_name'     => __( 'New Portfolio Category Name', 'mstudio' ),
			'menu_name'         => __( 'Portfolio Category', 'mstudio' ),
		);

		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'portfolio_category' ),
		);

		register_taxonomy( 'portfolio_categories', array( 'portfolio' ), $args );
	}
}


if ( ! function_exists('mstudio_testimonials') ) {
	function mstudio_testimonials() {
		$labels = array(
			'name'                  => _x( 'Testimonials', 'Post Type General Name', 'mstudio' ),
			'singular_name'         => _x( 'Testimonial', 'Post Type Singular Name', 'mstudio' ),
			'menu_name'             => __( 'Testimonials', 'mstudio' ),
			'name_admin_bar'        => __( 'Testimonials', 'mstudio' ),
			'parent_item_colon'     => __( 'Parent Testimonial:', 'mstudio' ),
			'all_items'             => __( 'All Testimonials', 'mstudio' ),
			'add_new_item'          => __( 'Add New Testimonial', 'mstudio' ),
			'add_new'               => __( 'New Testimonial', 'mstudio' ),
			'new_item'              => __( 'New Testimonial', 'mstudio' ),
			'edit_item'             => __( 'Edit Testimonial', 'mstudio' ),
			'update_item'           => __( 'Update Testimonial', 'mstudio' ),
			'view_item'             => __( 'View Testimonial', 'mstudio' ),
			'search_items'          => __( 'Search Testimonials', 'mstudio' ),
			'not_found'             => __( 'No testimonial found', 'mstudio' ),
			'not_found_in_trash'    => __( 'No testimonials found in Trash', 'mstudio' ),
			'items_list'            => __( 'Testimonials list', 'mstudio' ),
			'items_list_navigation' => __( 'Testimonials list navigation', 'mstudio' ),
			'filter_items_list'     => __( 'Filter testimonial list', 'mstudio' ),
		);
		$args = array(
			'label'                 => __( 'Testimonial', 'mstudio' ),
			'description'           => __( 'Testimonial Posts', 'mstudio' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'custom-fields', ),
			'taxonomies'            => array( 'testimonial_categories' ),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'             => 'dashicons-format-quote',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'capability_type'       => 'post',
		);
		register_post_type( 'testimonials', $args );
	}
	add_action( 'init', 'mstudio_testimonials', 0 );
}

if ( ! function_exists('mstudio_portfolio') ) {
	function mstudio_portfolio() {
		$labels = array(
			'name'                  => _x( 'Portfolios', 'Post Type General Name', 'mstudio' ),
			'singular_name'         => _x( 'Portfolio', 'Post Type Singular Name', 'mstudio' ),
			'menu_name'             => __( 'Portfolio', 'mstudio' ),
			'name_admin_bar'        => __( 'Portfolio', 'mstudio' ),
			'parent_item_colon'     => __( 'Parent Portfolio:', 'mstudio' ),
			'all_items'             => __( 'All Portfolios', 'mstudio' ),
			'add_new_item'          => __( 'Add New Portfolio', 'mstudio' ),
			'add_new'               => __( 'New Portfolio', 'mstudio' ),
			'new_item'              => __( 'New Portfolio', 'mstudio' ),
			'edit_item'             => __( 'Edit Portfolio', 'mstudio' ),
			'update_item'           => __( 'Update Portfolio', 'mstudio' ),
			'view_item'             => __( 'View Portfolio', 'mstudio' ),
			'search_items'          => __( 'Search Portfolios', 'mstudio' ),
			'not_found'             => __( 'No portfolio found', 'mstudio' ),
			'not_found_in_trash'    => __( 'No portfolio found in Trash', 'mstudio' ),
			'items_list'            => __( 'Portfolio list', 'mstudio' ),
			'items_list_navigation' => __( 'Portfolio list navigation', 'mstudio' ),
			'filter_items_list'     => __( 'Filter portfolio list', 'mstudio' ),
		);
		$args = array(
			'label'                 => __( 'Portfolio', 'mstudio' ),
			'description'           => __( 'Portfolio Posts', 'mstudio' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'custom-fields', 'comments' ),
			'taxonomies'            => array( 'portfolio_categories' ),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'             => 'dashicons-awards',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'capability_type'       => 'post',
		);
		register_post_type( 'portfolio', $args );
	}
	add_action( 'init', 'mstudio_portfolio', 0 );
}