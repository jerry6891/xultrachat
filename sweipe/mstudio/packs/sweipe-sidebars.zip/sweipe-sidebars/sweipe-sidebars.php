<?php
/*
Plugin Name: Sweipe Sidebars
Plugin URI: http://mobius.studio/
Description: Sidebars to put widgets in.
Author: Mobius Studio
Version: 1.0
Author URI: http://mobius.studio/
*/
function sweipe_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( '[Sweipe] Blog Sidebar', 'sweipe' ),
		'id'            => 'sweipe-blog-sidebar',
		'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'sweipe' ),
		'before_widget' => '<aside id="%1$s" class="tc-blog-sidebar-box widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( '[Sweipe] Before Menu', 'sweipe' ),
		'id'            => 'sweipe-before-menu',
		'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'sweipe' ),
		'before_widget' => '<aside id="%1$s" class="tc-blog-sidebar-box widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( '[Sweipe] After Menu', 'sweipe' ),
		'id'            => 'sweipe-after-menu',
		'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'sweipe' ),
		'before_widget' => '<aside id="%1$s" class="tc-blog-sidebar-box widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( '[Sweipe] Right Panel', 'sweipe' ),
		'id'            => 'sweipe-right-panel',
		'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'sweipe' ),
		'before_widget' => '<aside id="%1$s" class="tc-blog-sidebar-box widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'sweipe_widgets_init' );