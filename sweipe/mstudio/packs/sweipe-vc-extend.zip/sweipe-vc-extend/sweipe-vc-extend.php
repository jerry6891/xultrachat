<?php
/*
Plugin Name: Sweipe VC Extend
Plugin URI: http://mobius.studio/
Description: This plugin adds new shortcodes for Visual Composer.
Author: Mobius Studio
Version: 1.1
Author URI: http://mobius.studio/
*/
if( function_exists('vc_map') ):
require plugin_dir_path( __FILE__ ) . '/iconpicker.php';
class VCExtendAddonClass {
	function __construct() {
		// We safely integrate with VC with this hook
		add_action( 'init', array( $this, 'integrateWithVC' ) );

		// Use this when creating a shortcode addon

		$shortcodeList = array(
			'ms_icon_info_box',
			'ms_custom_title',
			'ms_testimonials_carousel',
			'ms_filterable_portfolio',
			'ms_progress_bar',
			'ms_user_card',
			'ms_activity_item',
			'ms_notification_box',
			'ms_countdown',
			'ms_gallery',
		);
		foreach($shortcodeList as $shortcodeName)
			add_shortcode( $shortcodeName, array( $this, $shortcodeName ) );
	}

	public function integrateWithVC() {

		/* Register "ms_icon_info_box" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Icon Info Box', 'mstudio' ),
			'base' => 'ms_icon_info_box',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Info Box with an Icon', 'mstudio' ),
			'admin_enqueue_css' => plugin_dir_url( __FILE__ ) . '/css/icons.css',
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Title', 'mstudio' ),
						'param_name' => 'title',
						'value' => __( 'Title Above Text', 'mstudio' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Text', 'mstudio' ),
						'param_name' => 'text',
						'value' => __( 'Text Below Title', 'mstudio' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => __( 'Icon', 'mstudio' ),
						'param_name' => 'icon_mstudio',
						'settings' => array(
							'emptyIcon' => false,
							'type' => 'mstudio',
							'iconsPerPage' => 200,
						),
						'description' => __( 'Select icon from library.', 'mstudio' ),
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_custom_title" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Custom Title', 'mstudio' ),
			'base' => 'ms_custom_title',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Title/Subtitle with Border at Bottom', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Title', 'mstudio' ),
						'param_name' => 'title',
						'value' => __( 'Title Text', 'mstudio' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Subtitle', 'mstudio' ),
						'param_name' => 'subtitle',
						'value' => __( 'Subtitle Text', 'mstudio' ),
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_testimonials_carousel" shortcode with vc_map */
		$args = array(
			'type'                     => 'post',
			'child_of'                 => 0,
			'parent'                   => '',
			'orderby'                  => 'name',
			'order'                    => 'ASC',
			'hide_empty'               => 1,
			'hierarchical'             => 0,
			'exclude'                  => '',
			'include'                  => '',
			'number'                   => '',
			'taxonomy'                 => 'testimonial_categories',
			'pad_counts'               => false

		);

		$categories = get_categories( $args );
		$testimonial_category_list = array();

		$testimonial_category_list['All'] = 0;
		foreach($categories as $category):
			$testimonial_category_list[$category->name] = $category->term_id;
		endforeach;
		vc_map( array(
			'name' => __( 'Testimonials Carousel', 'mstudio' ),
			'base' => 'ms_testimonials_carousel',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Show testimonials within touch enabled carousel.', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'dropdown',
						'param_name' => 'category',
						'value' => $testimonial_category_list,
						'heading' => __( 'Testimonials Category', 'mstudio' ),
						'description' => __( 'Choose a category to list items inside.', 'mstudio' ),
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_filterable_portfolio" shortcode with vc_map */
		$args = array(
			'type'                     => 'post',
			'child_of'                 => 0,
			'parent'                   => '',
			'orderby'                  => 'name',
			'order'                    => 'ASC',
			'hide_empty'               => 1,
			'hierarchical'             => 0,
			'exclude'                  => '',
			'include'                  => '',
			'number'                   => '',
			'taxonomy'                 => 'portfolio_categories',
			'pad_counts'               => false

		);

		$categories = get_categories( $args );
		$testimonial_category_list = array();

		foreach($categories as $category):
			$testimonial_category_list[$category->name] = $category->term_id;
		endforeach;
		vc_map( array(
			'name' => __( 'Filterable Portfolio', 'mstudio' ),
			'base' => 'ms_filterable_portfolio',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'List portfolio posts with filters.', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'checkbox',
						'param_name' => 'category',
						'heading' => __( 'Portfolio Categories.', 'mstudio' ),
						'description' => __( 'Choose from portfolio categories to list.', 'mstudio' ),
						'value' => $testimonial_category_list,
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_progress_bar" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Progress Bar', 'mstudio' ),
			'base' => 'ms_progress_bar',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Create a custom colored progress bar.', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Title', 'mstudio' ),
						'param_name' => 'title',
						'value' => __( 'Title Text', 'mstudio' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( '0 to 100', 'mstudio' ),
						'param_name' => 'progress',
						'value' => 50,
						'description' => __( 'Set progress from 0 to 100.', 'mstudio' ),
					),
					array(
						"type" => "colorpicker",
						"heading" => __( "Progress Color", "mstudio" ),
						"param_name" => "progress_color",
						"value" => '#F44336',
						"description" => __( "Pick a color for progress bar color.", "mstudio" )
					)
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_user_card" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'User Card', 'mstudio' ),
			'base' => 'ms_user_card',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'User card with background image and avatar.', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Title', 'mstudio' ),
						'param_name' => 'title',
						'value' => __( 'Title Text', 'mstudio' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Sub Title', 'mstudio' ),
						'param_name' => 'sub_title',
						'value' => __( 'Sub Title Text', 'mstudio' ),
					),
					array(
						'type' => 'attach_image',
						'heading' => __( 'Background Image', 'mstudio' ),
						'param_name' => 'bg_image',
					),
					array(
						'type' => 'attach_image',
						'heading' => __( 'Avatar', 'mstudio' ),
						'param_name' => 'avatar',
					)
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_activity_item" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Activity Item', 'mstudio' ),
			'base' => 'ms_activity_item',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Activity item with customization options.', 'mstudio' ),
			'admin_enqueue_css' => plugin_dir_url( __FILE__ ) . '/css/icons.css',
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Activity', 'mstudio' ),
						'param_name' => 'activity',
						'value' => __( 'Mitch ((followed)) you', 'mstudio' ),
						'description' => __( 'Text between (()) will be colored.', 'mstudio' ),
					),
					array(
						"type" => "colorpicker",
						"heading" => __( "Activity Color", "mstudio" ),
						"param_name" => "activity_color",
						"value" => '#3F51B5',
						"description" => __( "Color for the text which is between [[]].", "mstudio" )
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Sub Text', 'mstudio' ),
						'param_name' => 'sub_text',
						'value' => __( '16th January 2015', 'mstudio' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => __( 'Icon', 'mstudio' ),
						'param_name' => 'icon_mstudio',
						'settings' => array(
							'emptyIcon' => false,
							'type' => 'mstudio',
							'iconsPerPage' => 200,
						),
						'description' => __( 'Select icon from library.', 'mstudio' ),
					),
					array(
						'type' => 'attach_image',
						'heading' => __( 'Avatar', 'mstudio' ),
						'param_name' => 'avatar',
					),
					array(
						'type' => 'textarea_html',
						'heading' => __( 'Content', 'mstudio' ),
						'param_name' => 'content',
						'value' => __( 'You can enter detailed information here.', 'mstudio' ),
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_notification_box" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Notification Box', 'mstudio' ),
			'base' => 'ms_notification_box',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Notification box with styling options.', 'mstudio' ),
			'admin_enqueue_css' => plugin_dir_url( __FILE__ ) . '/css/icons.css',
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'title', 'mstudio' ),
						'param_name' => 'title',
						'value' => __( 'This is notification message.', 'mstudio' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Description', 'mstudio' ),
						'param_name' => 'description',
						'value' => __( 'Description below title.', 'mstudio' ),
					),
					array(
						"type" => "colorpicker",
						"heading" => __( "Background Color", "mstudio" ),
						"param_name" => "bg_color",
						"value" => '#D32F2F',
					),
					array(
						"type" => "colorpicker",
						"heading" => __( "Text Color", "mstudio" ),
						"param_name" => "text_color",
						"value" => '#ffffff',
					),
					array(
						'type' => 'iconpicker',
						'heading' => __( 'Icon', 'mstudio' ),
						'param_name' => 'icon_mstudio',
						'settings' => array(
							'emptyIcon' => false,
							'type' => 'mstudio',
							'iconsPerPage' => 200,
						),
						'description' => __( 'Select icon from library.', 'mstudio' ),
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );

		/* Register "ms_countdown" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Countdown', 'mstudio' ),
			'base' => 'ms_countdown',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Live Countdown with Customization', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'textfield',
						'heading' => __( 'DAY/MONTH/YEAR', 'mstudio' ),
						'param_name' => 'countdown',
						'value' => '03/05/2016',
						'description' => __( 'Count down to this date. Follow this format day/month/year', 'mstudio' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Days Label', 'mstudio' ),
						'param_name' => 'days_label',
						'value' => 'Days'
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Hours Label', 'mstudio' ),
						'param_name' => 'hours_label',
						'value' => 'Hours'
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Minutes Label', 'mstudio' ),
						'param_name' => 'minutes_label',
						'value' => 'Minutes'
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Seconds Label', 'mstudio' ),
						'param_name' => 'seconds_label',
						'value' => 'Seconds'
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Style', 'mstudio' ),
						'param_name' => 'style',
						'value' => array(
							__( 'Double Line', 'mstudio' ) => 'horizontal',
							__( 'Single Line', 'mstudio' ) => 'single-line',
						)
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );



		/* Register "ms_gallery" shortcode with vc_map */
		vc_map( array(
			'name' => __( 'Image Gallery', 'mstudio' ),
			'base' => 'ms_gallery',
			"icon" => plugin_dir_url( __FILE__ ) . '/images/logo-small.png',
			'category' => __( 'Custom', 'mstudio' ),
			'description' => __( 'Image Grid with Lightbox option.', 'mstudio' ),
			'params' =>
				array(
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column Count', 'mstudio' ),
						'param_name' => 'column_count',
						'value' => array(
							__('Two', 'mstudio') => 'two',
							__('Three', 'mstudio') => 'three',
							__('One', 'mstudio') => 'one',
							__('Four', 'mstudio') => 'four',
							__('Five', 'mstudio') => 'five',
						)
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Image Size', 'mstudio' ),
						'param_name' => 'image_size',
						'value' => __( '300x300', 'mstudio' ),
						'description' => __( 'WIDTHxHEIGHT. Image will scale down respectively. ', 'mstudio' ),
					),
					array(
						'type' => 'checkbox',
						'heading' => __( 'Hard Crop', 'mstudio' ),
						'param_name' => 'hardcrop',
						'value' => true
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Gap Size', 'mstudio' ),
						'param_name' => 'gap_size',
						'value' => '5',
						'description' => __( 'Space between images. Just enter a number and it will be used as pixels.', 'mstudio'),
					),
					array(
						'type' => 'attach_images',
						'heading' => __( 'Choose Images', 'mstudio' ),
						'param_name' => 'images',
					),
					array(
						'type' => 'checkbox',
						'heading' => __( 'Lightbox', 'mstudio' ),
						'param_name' => 'swipebox',
						'value' => true,
						'description' => __( 'Enable this to open full sized image with light box on click. Disabling links to attachment page.', 'mstudio'),
					),
				),
			'js_view' => '',
			'custom_markup' => '{{title}}',
		) );
	}

	/**
	 * Icon Info Box Shortcode
	 *
	 * @var $title
	 * @var $text
	 * @var $icon_mstudio
	 * @return string
	 */
	public function ms_icon_info_box( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title' => __( 'Title Above Text', 'mstudio' ),
			'text' => __( 'Text Below Title', 'mstudio' ),
			'icon_mstudio' => 'uiicon-tablet41'
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$output = "<div class='tc-icon-info-box clearfix'><i class='$icon_mstudio'></i><div><h4>$title</h4><p>$text</p></div></div>";
		return $output;
	}

	/**
	 * Custom Title Shortcode
	 *
	 * @var $title
	 * @var $subtitle
	 * @return string
	 */
	public function ms_custom_title( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title' => __( 'Title Text', 'mstudio' ),
			'subtitle' => __( 'Subtitle Text', 'mstudio' )
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$output = "<div class='tc-title-1'><h3 class='title'>$title</h3><h5 class='sub-title small-heading'>$subtitle</h5></div>";
		return $output;
	}

	/**
	 * Testimonials Carousel
	 *
	 * @var $title
	 * @var $subtitle
	 * @return string
	 */
	public function ms_testimonials_carousel( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'category' => 0
		), $atts ) );
		wp_enqueue_script( 'owlcarousel', plugin_dir_url( __FILE__ ) . '/js/owlcarousel.js', false, '', true );

		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$args = array(
			'category' => $category,
			'post_type' => 'testimonials'
		);

		$output = '';
		$args = array(
			'post_type' => 'testimonials',
			'tax_query' => array(
				array(
					'taxonomy' => 'testimonial_categories',
					'field'    => 'term_id',
					'terms'    => array( $category ),
				),
			),
		);

		$the_query = new WP_Query( $args );
		if($the_query->have_posts() ) :
			while ( $the_query->have_posts() ) : $the_query->the_post();

				$img = '';
				if ( has_post_thumbnail() ) {
					$the_post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
					if( is_array($the_post_thumbnail) && count($the_post_thumbnail) > 0 ){
						$img = '<img src="'.$the_post_thumbnail[0].'" alt="'.get_the_title().'" />';
					}
				}

				$output .= '<div class="item">
							<blockquote>'.get_the_content().'</blockquote>
							'.$img.'
							<h4>'.get_the_title().'</h4>
							<span>'.get_the_excerpt().'</span>
						</div>';
			endwhile;
		endif;
		wp_reset_query();

		$output = '<div class="owl-carousel tc-testimonial-carousel">'.$output.'</div>';
		return $output;
	}

	/**
	 * Filterable Portfolio
	 *
	 * @var $title
	 * @var $subtitle
	 * @return string
	 */
	public function ms_filterable_portfolio( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'category' => 0
		), $atts ) );
		wp_enqueue_script( 'isotope', plugin_dir_url( __FILE__ ) . '/js/isotope.js', false, '', true );
		wp_enqueue_script( 'imagesloaded', plugin_dir_url( __FILE__ ) . '/js/imagesLoaded.js', false, '', true );
		wp_enqueue_script( 'swipebox', plugin_dir_url( __FILE__ ) . '/js/swipebox.js', false, '', true );

		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$filter = $isotope = '';

		$args = array(
			'category' => $category,
			'post_type' => 'portfolio'
		);

		$category_args = array(
			'type'                     => 'post',
			'child_of'                 => 0,
			'parent'                   => '',
			'orderby'                  => 'name',
			'order'                    => 'ASC',
			'hide_empty'               => 1,
			'hierarchical'             => 0,
			'exclude'                  => '',
			'include'                  => $category,
			'number'                   => '',
			'taxonomy'                 => 'portfolio_categories',
			'pad_counts'               => false

		);

		$categories = get_categories( $category_args );

		/**
		 * Filter
		 */
		if( !empty( $categories ) ):
			$filter = '<div class="row margin-bottom-30"><div class="col-100"><div class="tc-filters clearfix"><span>'.__('Filter:','mstudio').'</span>';
			$filter .= '<a href="#" data-filter="*" class="active">All</a>';

			foreach( $categories as $category_list ):
				$filter .= '<a href="#" data-filter=".'.$category_list->slug.'">'.$category_list->name.'</a>';
			endforeach;

			$filter .= '</div></div></div>';
		endif;
		/* ------- */


		$isotope = '<div class="row no-gutter tc-isotope" data-gallery-id="'.uniqid('gallery-').'">';

		$portfolio_args = array( 'posts_per_page' => -1,
		                         'post_type' => 'portfolio',
		                         'tax_query' => array(
			                         array(
				                         'taxonomy' => 'portfolio_categories',
				                         'field' => 'term_id',
				                         'terms' => explode(',',$category),
			                         )
		                         )
		);

		$posts_array = get_posts( $portfolio_args );
		if( !empty( $posts_array ) ) :
			global $post;
			foreach ( $posts_array as $post ) : setup_postdata( $post );
				if ( has_post_thumbnail() ) {
					$posts_categories = wp_get_object_terms(get_the_ID(), 'portfolio_categories');
					$class_filter = '';

					foreach( $posts_categories as $posts_category ) $class_filter .= $posts_category->slug.' ';

					$the_src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );

					if( is_array( $the_src ) && count( $the_src ) > 0 ){
						$src = $the_src[0];
					}else{
						$src = '';
					}


					$isotope .= '<div class="tc-isotope-item col-50 tablet-33 '.trim($class_filter).'">';

					$isotope .= '<a href="'.$src.'" title="'.get_the_title().'" class="swipebox">';

					if( $src != '' ){ $isotope .= '<img  src="'.aq_resize($src,300, 300, 1).'" alt="'.get_the_title().'" />'; }

					$isotope .= '</a>';

					$isotope .= '</div>';
				}
			endforeach;
			wp_reset_postdata();
		endif;

		$isotope .= '</div>';

		if( !isset( $isotope ) ):
			$output = __( 'There are not any portfolio items.', 'mstudio' );
		else:
			$output = $filter.$isotope;
		endif;

		return $output;
	}

	/**
	 * Progress Bar Shortcode
	 *
	 * @var $title
	 * @var $progress
	 * @var $progress_color
	 * @return string
	 */
	public function ms_progress_bar( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title' => __( 'Title', 'mstudio' ),
			'progress' => 50,
			'progress_color' => '#F44336'
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$output = "<div class='tc-progress-bar clearfix'><strong>$title</strong><i>$progress%</i><div class='wrap'><div class='bar' style='background-color: $progress_color; width: $progress%'></div></div></div>";
		return $output;
	}

	/**
	 * User Card Shortcode
	 *
	 * @var $title
	 * @var $progress
	 * @var $progress_color
	 * @return string
	 */
	public function ms_user_card( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title' => __( 'Title', 'mstudio' ),
			'sub_title' => __( 'Sub Title', 'mstudio' ),
			'bg_image' => '',
			'avatar' => ''
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$_bg_image = wp_get_attachment_image_src( $bg_image, 'full' );
		$_avatar = wp_get_attachment_image_src( $avatar, 'full' );

		if( isset( $_bg_image[0] ) ){
			$bg_image = aq_resize($_bg_image[0],768, 512);
		}

		if( isset( $_avatar[0] ) ){
			$avatar = aq_resize($_avatar[0],90, 90);
		}

		$output = "<div class='tc-user-card'><div class='visuals'><img src='$bg_image' alt=''><div class='avatar'><img src='$avatar' alt='$title'></div></div><div class='details'><h2>$title</h2><span>$sub_title</span></div></div>";
		return $output;
	}

	/**
	 * Activity Item Shortcode
	 *
	 * @var $title
	 * @var $progress
	 * @var $progress_color
	 * @return string
	 */
	public function ms_activity_item( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'activity' => __( 'Mitch ((followed)) you', 'mstudio' ),
			'activity_color' => '#3F51B5',
			'sub_text' => __( '16th January 2015', 'mstudio' ),
			'icon_mstudio' => 'uiicon-tablet41',
			'avatar' => ''
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		$_avatar = wp_get_attachment_image_src( $avatar, 'full' );

		if( isset( $_avatar[0] ) ){
			$avatar = aq_resize($_avatar[0],50, 50, 1);
			$avatar = "<img src='$avatar' alt=''>";
		}

		if( '' != $activity ){
			$_search = array("((","))");
			$_replace = array("<span style='color: $activity_color'>","</span>");

			$activity = str_replace($_search,$_replace, $activity);
			$activity = "<h4>$activity</h4>";
		}

		if( '' != $icon_mstudio ){
			$icon_mstudio = "<i class='$icon_mstudio'></i>";
		}

		if( '' != $sub_text ){
			$sub_text = "<span>$sub_text</span>";
		}

		if( '' != $content ){
			$content = "<i class='uiicon-add63'></i><div class='content'>$content</div>";
		}

		$output = "<div class='ms-activity-item'><div class='head clearfix'>$avatar<div class='details'>$activity<div class='sub-text'>$icon_mstudio$sub_text</div></div></div>$content</div>";
		return $output;
	}

	/**
	 * Notification Box Shortcode
	 *
	 * @var $title
	 * @var $progress
	 * @var $progress_color
	 * @return string
	 */
	public function ms_notification_box( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title' => __( 'This is notification message.', 'mstudio' ),
			'description' => __( 'Description below title.', 'mstudio' ),
			'bg_color' => '#D32F2F',
			'text_color' => '#ffffff',
			'icon_mstudio' => 'uiicon-tablet41',
			'avatar' => ''
		), $atts ) );
		$content = wpb_js_remove_wpautop($content, true);

		if( '' != $description ){
			$description = "<div class='content'>$description</div>";
		}

		$output = "<div class='ms-notification-box' style='background-color: $bg_color; color: $text_color'><div class='head'><i class='$icon_mstudio'></i><span>This is notification message.</span></div>$description<i class='dismiss uiicon-add63'></i></div>";
		return $output;
	}

	/**
	 * Countdown Shortcode
	 *
	 * @var $title
	 * @var $progress
	 * @var $progress_color
	 * @return string
	 */
	public function ms_countdown( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'countdown' => '03/05/2016',
			'days_label' => __( 'Days', 'mstudio' ),
			'hours_label' => __( 'Hours', 'mstudio' ),
			'minutes_label' => __( 'Minutes', 'mstudio' ),
			'seconds_label' => __( 'Seconds', 'mstudio' ),
			'style' => 'horizontal',
		), $atts ) );
		wp_enqueue_script( 'countdown', plugin_dir_url( __FILE__ ) . '/js/countdown.js', false, '', true );

		$content = wpb_js_remove_wpautop($content, true);


		$output = "<div class='tc-countdown $style'data-end-date='$countdown'data-days-label='$days_label'data-hours-label='$hours_label'data-minutes-label='$minutes_label'data-seconds-label='$seconds_label'></div>";
		return $output;
	}

	/**
	 * Gallery Grid
	 *
	 * @var $title
	 * @var $progress
	 * @var $progress_color
	 * @return string
	 */
	public function ms_gallery( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column_count'  => 'two',
			'image_size'    => '300x300',
			'gap_size'      => 5,
			'images'        => array(),
			'swipebox'      => false,
			'hardcrop'      => false,
		), $atts ) );

		$output = $_rel = $_swipebox = '';
		//wp_enqueue_script('countdown');

		//$content = wpb_js_remove_wpautop($content, true);

		$column_search  = array('one','two','three','four','five');
		$column_replace = array(1,2,3,4,5);
		$column_count   = str_replace($column_search,$column_replace,$column_count);

		$gallery_id     = uniqid('ms-gallery-');
		$column_size    = 100 / $column_count;

		$gap_size       = (int) $gap_size;
		if( $gap_size > 0 )
			$gap_size   = $gap_size / 2;

		$hardcrop = (bool) $hardcrop;
		$swipebox = (bool) $swipebox;

		if( true === $swipebox ):
			wp_enqueue_script( 'swipebox', plugin_dir_url( __FILE__ ) . '/js/swipebox.js', false, '', true );

			$_rel = "rel='".uniqid("gallery-")."'";
			$_swipebox = 'swipebox';
		endif;

		$image_sizes = array(
			'width'     => null,
			'height'    => null
		);
		if( !empty( $image_size ) ):
			$_image_sizes           = explode('x', $image_size);
			$image_sizes['width']   = (int) $_image_sizes[0];
			$image_sizes['height']  = (int) $_image_sizes[1];;
		endif;

		if( !empty( $images ) ):
			wp_enqueue_script( 'imagesloaded', plugin_dir_url( __FILE__ ) . '/js/imagesLoaded.js', false, '', true );
			wp_enqueue_script( 'isotope', plugin_dir_url( __FILE__ ) . '/js/isotope.js', false, '', true );

			$image_urls      =
			$image_urls_full = array();
			$image_ids       = explode(',', $images);

			foreach( $image_ids as $image ):

				$_image_url = wp_get_attachment_image_src( $image, 'full' );
				if( isset( $_image_url[0] ) ):

					$image_urls[] =
						aq_resize(
							$_image_url[0],
							$image_sizes['width'],
							$image_sizes['height'],
							$hardcrop
						);

					if( !empty( $_swipebox ) ):
						$image_urls_full[] = $_image_url[0];
					else:
						$image_urls_full[] = get_attachment_link($image);
					endif;
				endif;

			endforeach;
		endif;

		if( empty( $image_urls ) ):
			$output = "<b style='color: red;'>".__('Please choose at least 1 image.','mstudio')."</b>";
		else:
			$output .= '<style>';
			$output .= "#$gallery_id > a{width: $column_size%}";
			if( $gap_size > 0 ){
				$output .= "#$gallery_id{margin: -$gap_size"."px}";
				$output .= "#$gallery_id > a{padding: $gap_size"."px}";
			}
			$output .= '</style>';

			$output .= "<div id='$gallery_id' class='ms-gallery-isotope clearfix'>";
			foreach( $image_urls as $k => $v ):
				$output .= "<a href='$image_urls_full[$k]' $_rel class='$_swipebox'>";
				$output .= "<img src='$v' alt='' />";
				$output .= "</a>";
			endforeach;
			$output .= '</div>';
		endif;

		return $output;
	}
}
// Finally initialize code
new VCExtendAddonClass();
endif;